/*
 * Copyright LWJGL. All rights reserved.
 * License terms: http://lwjgl.org/license.php
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.openal;

/** bindings to AL_EXT_MULAW extension. */
public final class EXTMulaw {

	/** AL_EXT_MULAW tokens. */
	public static final int
		AL_FORMAT_MONO_MULAW_EXT   = 0x10014,
		AL_FORMAT_STEREO_MULAW_EXT = 0x10015;

	private EXTMulaw() {}

}